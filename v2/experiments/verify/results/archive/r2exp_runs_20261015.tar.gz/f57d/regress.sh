#!/bin/bash
# F57c C2–C4 at fix-2026-10-f57d (notes/f57c_not_started_issue_prediction.md §4).
T=~/r2exp/f57d/tag/v2; OUT=~/r2exp/f57d/out/regress; mkdir -p "$OUT"; S="$OUT/summary.txt"; : > "$S"
P=~/r2exp/ha314/bin/python; run="systemd-run --user --scope -q python3 -u -m"
step() { local name=$1; shift; local t=$(date +%s); timeout 2400 "$@" > "$OUT/$name.log" 2>&1; echo "$name exit=$? seconds=$(( $(date +%s) - t ))" >> "$S"; }
cd "$T/framework" || exit 2
step house_a_down python3 -m confine.house_a down
step house_a_up python3 -m confine.house_a up
step c2_selftest_approval $run confine.selftest_approval
step c3_selftest_describe $run confine.selftest_describe
step c2_selftest_supervise $run confine.selftest_supervise --python $P
for m in M31 M32 M33 M34 M35 M39 M40 M41 M42 M43 M44; do
  MUT_ONLY=$m MUT_WORK=~/r2exp/f57d/mutwork bash "$T/verify/mutants/run_mutants.sh" "$T" "$OUT/mutants" > /dev/null 2>&1
done
echo ALLDONE >> "$S"
