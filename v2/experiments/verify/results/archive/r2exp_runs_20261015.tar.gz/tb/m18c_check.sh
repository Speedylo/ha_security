#!/bin/bash
# M18c's new check: fails against M18c, passes unmutated; then all 26 unmutated with the check in.
O=~/r2exp/tb/results_m18c_check; mkdir -p $O
h() { ( cd "$1/framework" && python3 -m confine.house_a "$2" ) >> $O/house_a.log 2>&1; }
h ~/r2exp/tb/src2/v2 down
h ~/r2exp/tb/work2/M18c up
( cd ~/r2exp/tb/work2/M18c/framework && timeout 300 systemd-run --user --scope -q python3 -m confine.selftest_real_platform ) > $O/mutated_real_platform.log 2>&1
echo "M18c with the check: exit=$?" >> $O/run.txt
h ~/r2exp/tb/work2/M18c down
h ~/r2exp/tb/src2/v2 up
( cd ~/r2exp/tb/src2/v2/framework && timeout 300 systemd-run --user --scope -q python3 -m confine.selftest_real_platform ) > $O/unmutated_real_platform.log 2>&1
echo "unmutated with the check: exit=$?" >> $O/run.txt
bash ~/r2exp/tb/src2/v2/experiments/selftests/suites_all.sh $O/suites_unmutated
echo "unmutated 26 suites: failed=$(grep -c "exit=[^0]" $O/suites_unmutated/summary.txt)" >> $O/run.txt
echo ALLDONE >> $O/run.txt
