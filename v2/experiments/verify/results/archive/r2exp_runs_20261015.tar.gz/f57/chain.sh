#!/bin/bash
until grep -q ALLDONE ~/r2exp/f58/out/regress/summary.txt; do sleep 60; done
bash ~/r2exp/f57/tag/v2/verify/regress_f57.sh
