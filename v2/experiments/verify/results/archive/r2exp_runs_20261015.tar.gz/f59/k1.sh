#!/bin/bash
# F59 K1: the test before the fix, at 55f3b8c (notes/f59_kept_storage_prediction.md §4).
OUT=~/r2exp/f59/out/k1; cd ~/r2exp/f59/test/v2/framework || exit 2
python3 -m confine.house_a down > $OUT/house_a_down.log 2>&1; echo "house_a_down exit=$?" > $OUT/summary.txt
python3 -m confine.house_a up > $OUT/house_a_up.log 2>&1; echo "house_a_up exit=$?" >> $OUT/summary.txt
systemd-run --user --scope -q python3 -u -m confine.selftest_keep > $OUT/selftest_keep.log 2>&1; echo "selftest_keep exit=$?" >> $OUT/summary.txt
echo ALLDONE >> $OUT/summary.txt
